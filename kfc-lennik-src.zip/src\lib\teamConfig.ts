// ── Team format config per category ────────────────────────────────────────────

export type TeamFormat = '2v2' | '3v3' | '5v5' | '8v8' | '11v11';

export const CATEGORY_FORMAT: Record<string, TeamFormat> = {
  U6:  '2v2',
  U7:  '3v3',
  U8:  '5v5',
  U9:  '5v5',
  U10: '8v8',
  U11: '8v8',
  U12: '8v8',
  U13: '11v11',
  U15: '11v11',
  U17: '11v11',
};

export const FORMAT_LABEL: Record<TeamFormat, string> = {
  '2v2':   '2 tegen 2',
  '3v3':   '3 tegen 3',
  '5v5':   '5 tegen 5',
  '8v8':   '8 tegen 8',
  '11v11': '11 tegen 11',
};

export const FORMAT_PERIOD_DURATION: Record<TeamFormat, number> = {
  '2v2':   10 * 60,
  '3v3':   10 * 60,
  '5v5':   15 * 60,
  '8v8':   20 * 60,
  '11v11': 25 * 60,
};

export const FORMAT_PERIODS: Record<TeamFormat, number> = {
  '2v2': 4, '3v3': 4, '5v5': 4, '8v8': 4, '11v11': 4,
};

// Per-category override: U10/U11 spelen kwartieren van 15 min, U12/U13 van 20 min.
export const CATEGORY_PERIOD_DURATION: Partial<Record<string, number>> = {
  U10: 15 * 60,
  U11: 15 * 60,
  U12: 20 * 60,
  U13: 20 * 60,
};

// ── Field positions per format ──────────────────────────────────────────────────
// x/y as percent of the 370×480 SVG viewBox
// y=100 = bottom (our goal), y=0 = top (opponent goal)
// Positions derived from the uploaded reference images.

export interface FieldPos {
  key: string;
  label: string;
  role: 'keeper' | 'defender' | 'midfielder' | 'forward';
  x: number;   // 0–100 %
  y: number;   // 0–100 %
}

const POSITIONS: Record<TeamFormat, FieldPos[]> = {

  // ── 2v2: keeper + 1 aanvaller ───────────────────────────────────────────────
  '2v2': [
    { key: 'K', label: 'K', role: 'keeper',  x: 50, y: 87 },
    { key: '9', label: '9', role: 'forward', x: 50, y: 20 },
  ],

  // ── 3v3: keeper + 1 verdediger + 1 aanvaller ────────────────────────────────
  '3v3': [
    { key: 'K', label: 'K', role: 'keeper',   x: 50, y: 87 },
    { key: '3', label: '3', role: 'defender', x: 50, y: 65 },
    { key: '9', label: '9', role: 'forward',  x: 50, y: 20 },
  ],

  // ── 5v5: based on image 2 ────────────────────────────────────────────────────
  // K(1) bottom center, 3 center-mid, 9 center-attack, 7 right-wing, 11 left-wing
  '5v5': [
    { key: 'K',  label: 'K',  role: 'keeper',   x: 50,  y: 87 },
    { key: '3',  label: '3',  role: 'defender', x: 50,  y: 60 },
    { key: '11', label: '11', role: 'forward',  x: 8,   y: 40 },
    { key: '7',  label: '7',  role: 'forward',  x: 92,  y: 40 },
    { key: '9',  label: '9',  role: 'forward',  x: 50,  y: 22 },
  ],

  // ── 8v8: K + 3 def + 1 mid + 2 wings + 1 fwd — uit referentiefoto ─────────
  // K(1) onderaan, 5-3-2 verdediging, 6 centraal, 11 links / 7 rechts, 9 spits
  '8v8': [
    { key: 'K',  label: 'K',  role: 'keeper',    x: 50,  y: 88 },
    { key: '5',  label: '5',  role: 'defender',  x: 14,  y: 65 },
    { key: '3',  label: '3',  role: 'defender',  x: 50,  y: 67 },
    { key: '2',  label: '2',  role: 'defender',  x: 82,  y: 65 },
    { key: '6',  label: '6',  role: 'midfielder',x: 50,  y: 51 },
    { key: '11', label: '11', role: 'midfielder',x: 12,  y: 36 },
    { key: '7',  label: '7',  role: 'midfielder',x: 82,  y: 36 },
    { key: '9',  label: '9',  role: 'forward',   x: 50,  y: 22 },
  ],

  // ── 11v11: based on image 1 (4-3-3) ─────────────────────────────────────────
  // Bottom to top from image:
  // Row 1 (keeper):  K(1) center-bottom
  // Row 2 (def):     4 center-left, 3 center-right, 5 far-left, 2 far-right
  // Row 3 (mid):     6 center-left, 8 center-right
  // Row 4 (att-mid): 10 center
  // Row 5 (fwd):     11 far-left, 9 center, 7 far-right
  '11v11': [
    { key: 'K',  label: 'K',  role: 'keeper',    x: 50,  y: 88 },
    { key: '5',  label: '5',  role: 'defender',  x: 16,  y: 76 },
    { key: '4',  label: '4',  role: 'defender',  x: 38,  y: 74 },
    { key: '3',  label: '3',  role: 'defender',  x: 62,  y: 74 },
    { key: '2',  label: '2',  role: 'defender',  x: 84,  y: 76 },
    { key: '6',  label: '6',  role: 'midfielder',x: 40,  y: 58 },
    { key: '8',  label: '8',  role: 'midfielder',x: 62,  y: 56 },
    { key: '10', label: '10', role: 'midfielder',x: 50,  y: 43 },
    { key: '11', label: '11', role: 'forward',   x: 22,  y: 22 },
    { key: '9',  label: '9',  role: 'forward',   x: 50,  y: 13 },
    { key: '7',  label: '7',  role: 'forward',   x: 78,  y: 22 },
  ],
};

export function getPositionsForFormat(format: TeamFormat): FieldPos[] {
  return POSITIONS[format];
}

export function getPositionsForCategory(category: string): FieldPos[] {
  const format = CATEGORY_FORMAT[category] ?? '11v11';
  return getPositionsForFormat(format);
}

export function getFormatForCategory(category: string): TeamFormat {
  return CATEGORY_FORMAT[category] ?? '11v11';
}

export function getPeriodDuration(category: string): number {
  const override = CATEGORY_PERIOD_DURATION[category];
  if (override) return override;
  const format = CATEGORY_FORMAT[category] ?? '11v11';
  return FORMAT_PERIOD_DURATION[format];
}
